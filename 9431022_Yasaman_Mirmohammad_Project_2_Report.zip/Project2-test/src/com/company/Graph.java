package com.company;

import java.util.ArrayList;

/**
 * Created by Admin on 12/27/2016.
 */
public class Graph {
    ArrayList<Node> nodelist = new ArrayList<>() ;   //listi az node haa

}
