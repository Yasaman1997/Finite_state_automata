package com.company;

/**
 * Created by Admin on 12/27/2016.
 */
public class Edge {
    int nextnode; //node i ke behesh vasle(node nahaii)
    char value;  //meghdare yaal


}
